# CoraLotoRD Backend

Este backend está listo para ser desplegado en Render, Railway o tu propio servidor con Docker.

## Pasos para usarlo

1. Sube este proyecto a GitHub.
2. Conéctalo a [https://render.com](https://render.com) como servicio web.
3. Usa `Docker` como tipo de entorno y se configurará automáticamente.

También puedes correrlo localmente:
```bash
pip install -r requirements.txt
python Historial_Perfil_Vistas.py
```
